package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;

class TicketControllerV1Test {

}